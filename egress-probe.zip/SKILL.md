---
name: egress-probe
description: >
  Determines whether the Gemini Enterprise skill sandbox has any outbound
  network access at all, by bypassing DNS entirely and connecting to known
  IP addresses directly. Use when a skill cannot reach an external API,
  when hostname resolution fails with "Temporary failure in name
  resolution", or when the user asks whether the sandbox can reach
  BigQuery or the internet. Also use when invoked as @egress-probe or
  /egress-probe.
---

# Egress Probe

A throwaway troubleshooting skill. It reads no business data. It answers
one question: can anything leave this sandbox?

## Why this exists

"Temporary failure in name resolution" appears in two completely different
situations — egress is blocked, or egress works but no DNS resolver is
configured. The first has no fix. The second is fixable in code. An
earlier diagnostic could not tell them apart, because both surface as the
same error.

This probe skips DNS: it talks to public resolvers over raw UDP, opens TCP
to known IP addresses, and attempts a real TLS handshake to Google with no
hostname lookup involved.

## What to do

```
python3 scripts/egress_probe.py
```

Report the `verdict` and `explanation` first, then every check, including
the ones that passed — a partial result is the interesting case here and
the passing checks are what locate the boundary.

## Rules

**Report the raw output.** Exact error types and messages. The difference
between a timeout and a connection refusal is the whole point of running
this.

**Do not conclude beyond the verdict.** This probe tests network
reachability only. It tests nothing about credentials, IAM, or dataset
permissions.

**Do not attempt a workaround.** Do not try other hosts, install packages,
or query anything. Report and stop.

## Reading the verdict

| Verdict | Means |
|---|---|
| `EGRESS_WORKS_DNS_WAS_MISSING` | The network is open; only the resolver was absent. A skill can reach BigQuery by resolving in code. Authentication becomes the remaining problem. |
| `PARTIAL_EGRESS` | Some traffic leaves but the HTTPS path did not complete. Read the individual checks to find the boundary. |
| `NO_EGRESS` | Nothing leaves, even to a raw IP with no DNS involved. Full isolation. No code change reaches BigQuery from a skill here. |
