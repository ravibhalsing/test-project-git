---
name: sandbox-auth-diagnostic
description: >
  Diagnoses whether the Gemini Enterprise skill sandbox has a usable Google
  Cloud identity, and reports exactly why database authentication is
  failing. Use when a skill that queries BigQuery returns a Metadata Auth
  Error, a credentials error, or any authentication failure, or when the
  user asks to check sandbox permissions, service account access, or
  network reachability. Also use when invoked as @sandbox-auth-diagnostic
  or /sandbox-auth-diagnostic.
---

# Sandbox Auth Diagnostic

A throwaway troubleshooting skill. It queries nothing and reads no business
data — it only reports what identity and network access this sandbox has.

## What to do

Run the script and report its output:

```
python3 scripts/diag.py
```

Then present the results:

1. State the `verdict` and its `explanation` first.
2. List every check where `ok` is false, with its `detail` and, where
   present, its `means` field.
3. Stop there.

## Rules

**Report the raw output.** Print the actual error strings. A paraphrase
loses the distinction between a DNS failure, a connection refusal, and an
HTTP 404 — and those three have completely different fixes.

**Do not diagnose beyond the data.** If the script says
`NO_METADATA_SERVER`, say that. Do not speculate about IAM roles, quota,
or billing, none of which this script tested.

**Do not suggest workarounds.** Not Drive, not Search, not "try asking a
colleague". The purpose of this run is a clean answer about sandbox
capability, and a helpful detour obscures it.

**If the script itself fails to run**, that is the most important result
in the whole exercise: it means script execution is unavailable, not that
authentication is broken. Report it plainly and say so.

## Reading the verdict

| Verdict | Means |
|---|---|
| `AUTH_WORKS` | Identity is fine. A query failure is IAM on the dataset. |
| `NO_SERVICE_ACCOUNT_ATTACHED` | Metadata server present, no identity on it. A provisioning question. |
| `NO_METADATA_SERVER` | Not a GCE-style sandbox. No identity to fetch, and no configuration change inside the skill will produce one. |
| `UNCLEAR` | Read the individual checks. |
